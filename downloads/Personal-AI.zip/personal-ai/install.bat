@echo off
cd /d %~dp0
echo ===== Personal AI Setup =====
python --version >nul 2>&1 || (echo Python nahi mila. python.org se install karo, "Add to PATH" tick karke. & pause & exit /b)
ollama --version >nul 2>&1 || (echo Ollama nahi mila. ollama.com/download se install karo. & pause & exit /b)
python -m pip install -r requirements.txt
python setup_models.py
powershell -NoProfile -Command "$s=(New-Object -ComObject WScript.Shell).CreateShortcut([Environment]::GetFolderPath('Desktop')+'\Personal AI.lnk');$s.TargetPath='%~dp0start.bat';$s.WorkingDirectory='%~dp0';$s.Save()"
echo.
echo Ho gaya! Desktop pe "Personal AI" icon pe double-click karo.
pause
