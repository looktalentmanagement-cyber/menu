@echo off
cd /d %~dp0
start "" /min cmd /c "ollama serve >nul 2>&1"
python app.py
