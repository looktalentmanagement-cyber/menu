"""Laptop ki RAM dekh ke sahi AI model download karta hai (sirf pehli baar internet chahiye)."""
import json, os, subprocess, psutil
ram = psutil.virtual_memory().total / 1024**3
if ram >= 14:   chat = "qwen2.5:7b"
elif ram >= 7:  chat = "qwen2.5:3b"
else:           chat = "qwen2.5:1.5b"
embed = "bge-m3"   # books padhne ke liye (Hindi + English)
print(f"RAM: {ram:.0f} GB  ->  model: {chat}")
for m in (chat, embed):
    print(f"Downloading {m} ... (pehli baar thoda time lagega)")
    subprocess.run(["ollama", "pull", m], check=True)
cfg_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "config.json")
cfg = json.load(open(cfg_path)) if os.path.exists(cfg_path) else {}
cfg.update({"model": chat, "embed": embed})
cfg.setdefault("bot_name", "Dost")
json.dump(cfg, open(cfg_path, "w"), indent=2)
print("Setup complete!")
