"""
Personal AI - offline chatbot for Windows
Chat (Hinglish) + file move/copy/find + books + photos + invoice + reminders + stories.
Runs fully offline after setup (Ollama local model). Opens in your browser at http://127.0.0.1:7860
"""
import os, json, shutil, glob, threading, time, datetime as dt, fnmatch
os.environ["GRADIO_ANALYTICS_ENABLED"] = "False"
import numpy as np
import gradio as gr
import ollama
from pypdf import PdfReader
import docx
from fpdf import FPDF

try:
    from plyer import notification
except Exception:
    notification = None

# ------------------------------------------------------------------ paths & config
BASE = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.join(BASE, "data")
BOOKS = os.path.join(DATA, "books")
PHOTOS = os.path.join(DATA, "photos")
INVOICES = os.path.join(DATA, "invoices")
STORIES = os.path.join(DATA, "stories")
for d in (DATA, BOOKS, PHOTOS, INVOICES, STORIES):
    os.makedirs(d, exist_ok=True)
CFG_PATH = os.path.join(BASE, "config.json")
REM_PATH = os.path.join(DATA, "reminders.json")
IDX_TXT = os.path.join(DATA, "book_index.json")
IDX_VEC = os.path.join(DATA, "book_index.npy")
UNDO_PATH = os.path.join(DATA, "undo.json")

def load_cfg():
    cfg = {"model": "qwen2.5:3b", "embed": "bge-m3", "bot_name": "Dost",
           "business": "AK Media", "gstin": "", "address": "", "phone": ""}
    if os.path.exists(CFG_PATH):
        cfg.update(json.load(open(CFG_PATH, encoding="utf-8")))
    return cfg

CFG = load_cfg()
def save_cfg():
    json.dump(CFG, open(CFG_PATH, "w", encoding="utf-8"), indent=2, ensure_ascii=False)

HOME = os.path.expanduser("~")
def known_folders():
    names = {"desktop": "Desktop", "downloads": "Downloads", "documents": "Documents",
             "pictures": "Pictures", "photos": "Pictures", "videos": "Videos", "music": "Music"}
    out = {}
    for k, v in names.items():
        for root in (os.path.join(HOME, "OneDrive"), HOME):
            p = os.path.join(root, v)
            if os.path.isdir(p):
                out[k] = p
                break
    out["books"] = BOOKS; out["my photos"] = PHOTOS; out["invoices"] = INVOICES; out["stories"] = STORIES
    return out

def resolve(path):
    """'Desktop', 'Downloads\\abc', 'D:\\Photos' sab samajhta hai."""
    if not path:
        return HOME
    path = path.strip().strip('"')
    kf = known_folders()
    low = path.lower().replace("/", "\\")
    first, _, rest = low.partition("\\")
    if first in kf:
        return os.path.join(kf[first], path[len(first) + 1:]) if rest else kf[first]
    if os.path.isabs(path):
        return path
    return os.path.join(HOME, path)

# ------------------------------------------------------------------ undo log
def log_moves(pairs):
    json.dump(pairs, open(UNDO_PATH, "w", encoding="utf-8"))

def undo_last():
    if not os.path.exists(UNDO_PATH):
        return "Undo karne ke liye kuch nahi hai."
    pairs = json.load(open(UNDO_PATH, encoding="utf-8"))
    n = 0
    for src, dst in reversed(pairs):
        if os.path.exists(dst):
            os.makedirs(os.path.dirname(src), exist_ok=True)
            shutil.move(dst, src); n += 1
    os.remove(UNDO_PATH)
    return f"{n} file wapas apni jagah rakh di."

# ------------------------------------------------------------------ book index
def _load_index():
    if os.path.exists(IDX_TXT) and os.path.exists(IDX_VEC):
        return json.load(open(IDX_TXT, encoding="utf-8")), np.load(IDX_VEC)
    return [], np.zeros((0, 1), dtype=np.float32)

def _embed(texts):
    vecs = []
    for i in range(0, len(texts), 16):
        r = ollama.embed(model=CFG["embed"], input=texts[i:i + 16])
        vecs.extend(r["embeddings"])
    v = np.array(vecs, dtype=np.float32)
    return v / (np.linalg.norm(v, axis=1, keepdims=True) + 1e-9)

def _pages(path):
    ext = os.path.splitext(path)[1].lower()
    if ext == ".pdf":
        for i, p in enumerate(PdfReader(path).pages, 1):
            yield i, (p.extract_text() or "")
    elif ext == ".docx":
        text = "\n".join(p.text for p in docx.Document(path).paragraphs)
        for i in range(0, len(text), 3000):
            yield i // 3000 + 1, text[i:i + 3000]
    else:
        text = open(path, encoding="utf-8", errors="ignore").read()
        for i in range(0, len(text), 3000):
            yield i // 3000 + 1, text[i:i + 3000]

def add_books(files, progress=None):
    if not files:
        return "Pehle book choose karo.", book_list()
    meta, vecs = _load_index()
    msgs = []
    for f in files:
        src = f if isinstance(f, str) else f.name
        name = os.path.basename(src)
        dst = os.path.join(BOOKS, name)
        if os.path.abspath(src) != os.path.abspath(dst):
            shutil.copy(src, dst)
        chunks = []
        for page, text in _pages(dst):
            text = " ".join(text.split())
            for j in range(0, len(text), 900):
                piece = text[j:j + 1000]
                if len(piece) > 40:
                    chunks.append({"book": name, "page": page, "text": piece})
        if not chunks:
            msgs.append(f"{name}: text nahi mila (scan wali PDF ho sakti hai)."); continue
        new = _embed([c["text"] for c in chunks])
        keep = [i for i, m in enumerate(meta) if m["book"] != name]   # re-upload replaces old copy
        meta = [meta[i] for i in keep] + chunks
        vecs = np.vstack([vecs[keep], new]) if keep else new
        json.dump(meta, open(IDX_TXT, "w", encoding="utf-8"), ensure_ascii=False)
        np.save(IDX_VEC, vecs)
        msgs.append(f"{name}: {len(chunks)} hisse padh liye, ab isse sawal pucho.")
    return "\n".join(msgs), book_list()

def book_list():
    return "\n".join(sorted(os.listdir(BOOKS))) or "Abhi koi book nahi."

# ------------------------------------------------------------------ tools the AI can use
def search_books(question: str) -> str:
    """Uploaded books mein se question ka jawab dhoondho. Returns matching passages with book name and page.

    Args:
        question: kya dhoondhna hai
    """
    meta, vecs = _load_index()
    if not meta:
        return "Koi book upload nahi hai."
    q = _embed([question])[0]
    top = np.argsort(-(vecs @ q))[:4]
    return "\n\n".join(f"[{meta[i]['book']}, page {meta[i]['page']}] {meta[i]['text']}" for i in top)

def find_files(name: str, folder: str = "") -> str:
    """Computer mein file ya folder dhoondho naam se (jaise 'invoice', '*.jpg', 'resume').

    Args:
        name: file ka naam ya pattern
        folder: kahan dhoondhna hai (Desktop, Downloads, Documents, Pictures ya pura path). Khali = sab jagah
    """
    roots = [resolve(folder)] if folder else list(dict.fromkeys(known_folders().values()))
    pat = name if any(c in name for c in "*?") else f"*{name}*"
    found = []
    for r in roots:
        for dp, dns, fns in os.walk(r):
            for n in dns + fns:
                if fnmatch.fnmatch(n.lower(), pat.lower()):
                    found.append(os.path.join(dp, n))
                    if len(found) >= 30:
                        return "\n".join(found) + "\n(aur bhi ho sakti hain)"
    return "\n".join(found) or "Kuch nahi mila."

def list_folder(folder: str) -> str:
    """Folder ke andar kya-kya hai dikhao.

    Args:
        folder: Desktop, Downloads, Documents, Pictures ya pura path
    """
    p = resolve(folder)
    if not os.path.isdir(p):
        return f"Folder nahi mila: {p}"
    items = sorted(os.listdir(p))
    return f"{p} ({len(items)} items)\n" + "\n".join(items[:60])

def _transfer(source, destination, pattern, mode):
    src, dst = resolve(source), resolve(destination)
    os.makedirs(dst, exist_ok=True)
    if os.path.isdir(src):
        files = [os.path.join(src, f) for f in os.listdir(src)
                 if fnmatch.fnmatch(f.lower(), (pattern or "*").lower()) and os.path.isfile(os.path.join(src, f))]
    elif os.path.exists(src):
        files = [src]
    else:
        files = glob.glob(src)
    if not files:
        return f"{src} mein aisi koi file nahi mili."
    done = []
    for f in files:
        target = os.path.join(dst, os.path.basename(f))
        base, ext = os.path.splitext(target); k = 1
        while os.path.exists(target):
            target = f"{base} ({k}){ext}"; k += 1
        (shutil.move if mode == "move" else shutil.copy2)(f, target)
        done.append([f, target])
    if mode == "move":
        log_moves(done)
    word = "move" if mode == "move" else "copy"
    return f"{len(done)} file {word} ki: {src} -> {dst}"

def move_files(source: str, destination: str, pattern: str = "*") -> str:
    """Files ek jagah se doosri jagah MOVE karo. Undo button se wapas ho sakta hai.

    Args:
        source: kahan se (folder ya file, jaise 'Downloads')
        destination: kahan (jaise 'Pictures\\Shaadi')
        pattern: kaunsi files (jaise '*.jpg', '*.pdf'). Sab ke liye '*'
    """
    return _transfer(source, destination, pattern, "move")

def copy_files(source: str, destination: str, pattern: str = "*") -> str:
    """Files COPY karo ek jagah se doosri jagah.

    Args:
        source: kahan se
        destination: kahan
        pattern: kaunsi files, jaise '*.jpg'
    """
    return _transfer(source, destination, pattern, "copy")

def make_invoice(customer: str, items: list, gst_percent: float = 18) -> str:
    """GST invoice PDF banao.

    Args:
        customer: customer ka naam
        items: list of items, har item {"name": str, "qty": number, "rate": number}
        gst_percent: GST percent (0, 5, 12, 18, 28)
    """
    path = _invoice_pdf(customer, "", items, gst_percent)
    return f"Invoice ban gaya: {path}"

def set_reminder(text: str, when: str) -> str:
    """Reminder set karo.

    Args:
        text: kis baat ka reminder
        when: date aur time 'YYYY-MM-DD HH:MM' format mein (24 ghante)
    """
    try:
        t = dt.datetime.strptime(when.strip(), "%Y-%m-%d %H:%M")
    except ValueError:
        return "Time samajh nahi aaya, 'YYYY-MM-DD HH:MM' chahiye."
    rems = _load_rem()
    rems.append({"text": text, "when": t.strftime("%Y-%m-%d %H:%M"), "done": False})
    _save_rem(rems)
    return f"Reminder set: {t.strftime('%d %b %Y, %I:%M %p')} - {text}"

def save_story(title: str, text: str) -> str:
    """Likhi hui story/letter/content ko file mein save karo.

    Args:
        title: naam
        text: poora text
    """
    safe = "".join(c for c in title if c.isalnum() or c in " -_").strip() or "story"
    p = os.path.join(STORIES, f"{safe}.txt")
    open(p, "w", encoding="utf-8").write(text)
    return f"Save ho gaya: {p}"

TOOLS = [search_books, find_files, list_folder, move_files, copy_files,
         make_invoice, set_reminder, save_story]
TOOL_MAP = {f.__name__: f for f in TOOLS}

# ------------------------------------------------------------------ invoice pdf
def _invoice_pdf(customer, cust_addr, items, gst):
    no = dt.datetime.now().strftime("INV-%Y%m%d-%H%M%S")
    pdf = FPDF(); pdf.add_page()
    pdf.set_font("Helvetica", "B", 18); pdf.cell(0, 10, CFG.get("business", ""), ln=1)
    pdf.set_font("Helvetica", "", 10)
    for line in (CFG.get("address", ""), f"Phone: {CFG.get('phone','')}" if CFG.get("phone") else "",
                 f"GSTIN: {CFG.get('gstin','')}" if CFG.get("gstin") else ""):
        if line: pdf.cell(0, 5, line, ln=1)
    pdf.ln(4); pdf.set_font("Helvetica", "B", 14); pdf.cell(0, 8, "TAX INVOICE", ln=1)
    pdf.set_font("Helvetica", "", 10)
    pdf.cell(0, 5, f"Invoice No: {no}    Date: {dt.date.today():%d-%m-%Y}", ln=1)
    pdf.cell(0, 5, f"Bill To: {customer}", ln=1)
    if cust_addr: pdf.multi_cell(0, 5, cust_addr)
    pdf.ln(3); pdf.set_font("Helvetica", "B", 10)
    for w, h in ((90, "Item"), (25, "Qty"), (35, "Rate"), (40, "Amount")):
        pdf.cell(w, 8, h, border=1)
    pdf.ln(); pdf.set_font("Helvetica", "", 10)
    sub = 0.0
    for it in items:
        q, r = float(it.get("qty", 1)), float(it.get("rate", 0)); amt = q * r; sub += amt
        pdf.cell(90, 8, str(it.get("name", ""))[:45], border=1); pdf.cell(25, 8, f"{q:g}", border=1)
        pdf.cell(35, 8, f"{r:,.2f}", border=1); pdf.cell(40, 8, f"{amt:,.2f}", border=1); pdf.ln()
    tax = sub * float(gst) / 100
    for label, val in ((f"Subtotal", sub), (f"CGST {gst/2:g}%", tax / 2), (f"SGST {gst/2:g}%", tax / 2),
                       ("TOTAL (Rs.)", sub + tax)):
        pdf.cell(150, 8, label, border=1, align="R"); pdf.cell(40, 8, f"{val:,.2f}", border=1); pdf.ln()
    pdf.ln(10); pdf.cell(0, 5, "Thank you for your business!", ln=1)
    path = os.path.join(INVOICES, f"{no}_{''.join(c for c in customer if c.isalnum())[:20]}.pdf")
    pdf.output(path)
    return path

def invoice_from_form(customer, addr, items_text, gst):
    items = []
    for line in (items_text or "").splitlines():
        parts = [p.strip() for p in line.split(",")]
        if len(parts) >= 3 and parts[0]:
            try: items.append({"name": parts[0], "qty": float(parts[1]), "rate": float(parts[2])})
            except ValueError: pass
    if not customer or not items:
        return None, "Customer naam aur kam se kam 1 item likho (naam, qty, rate)."
    p = _invoice_pdf(customer, addr, items, float(gst))
    return p, f"Invoice ban gaya: {os.path.basename(p)}"

# ------------------------------------------------------------------ reminders
_rem_lock = threading.Lock()
def _load_rem():
    with _rem_lock:
        return json.load(open(REM_PATH, encoding="utf-8")) if os.path.exists(REM_PATH) else []
def _save_rem(r):
    with _rem_lock:
        json.dump(r, open(REM_PATH, "w", encoding="utf-8"), indent=2, ensure_ascii=False)

def reminder_table():
    return [[r["when"], r["text"], "Ho gaya" if r["done"] else "Baaki"] for r in sorted(_load_rem(), key=lambda x: x["when"])]

def add_reminder_form(text, date, tm):
    msg = set_reminder(text, f"{date} {tm}")
    return msg, reminder_table()

def clear_done():
    _save_rem([r for r in _load_rem() if not r["done"]]); return reminder_table()

def reminder_loop():
    while True:
        now = dt.datetime.now().strftime("%Y-%m-%d %H:%M")
        rems = _load_rem(); changed = False
        for r in rems:
            if not r["done"] and r["when"] <= now:
                r["done"] = True; changed = True
                if notification:
                    try: notification.notify(title=f"{CFG['bot_name']} Reminder", message=r["text"], timeout=20)
                    except Exception: pass
                print("REMINDER:", r["text"])
        if changed: _save_rem(rems)
        time.sleep(20)

# ------------------------------------------------------------------ chat
def system_prompt():
    now = dt.datetime.now()
    folders = ", ".join(f"{k}={v}" for k, v in known_folders().items())
    return (f"Tumhara naam {CFG['bot_name']} hai. Tum user ke personal AI assistant ho jo unke Windows computer pe offline chalte ho. "
            "Hinglish mein, chhote, friendly jawab do. User ki spelling galat ho sakti hai, matlab samajh ke kaam karo. "
            f"Aaj {now:%A, %d %B %Y}, time {now:%H:%M} hai. "
            f"User ke folders: {folders}. "
            "Files dhoondhne, move/copy karne, books se jawab, invoice, reminder aur story save karne ke liye tools use karo. "
            "Books ka sawal ho to pehle search_books chalao aur book ka naam aur page batao. "
            "Kabhi file delete mat karo. Kaam karne ke baad batao kya kiya. Story/letter maange to khud likho, aur save karne ko kahe to save_story.")

def chat(message, history):
    msgs = [{"role": "system", "content": system_prompt()}]
    for h in history[-12:]:
        if h.get("role") in ("user", "assistant") and isinstance(h.get("content"), str):
            msgs.append({"role": h["role"], "content": h["content"]})
    msgs.append({"role": "user", "content": message})
    try:
        for _ in range(6):
            r = ollama.chat(model=CFG["model"], messages=msgs, tools=TOOLS)
            m = r.message
            if not m.tool_calls:
                return m.content
            msgs.append(m)
            for tc in m.tool_calls:
                fn = TOOL_MAP.get(tc.function.name)
                try:
                    out = fn(**(tc.function.arguments or {})) if fn else "Unknown tool"
                except Exception as e:
                    out = f"Error: {e}"
                msgs.append({"role": "tool", "content": str(out), "tool_name": tc.function.name})
        return "Kaam thoda lamba ho gaya, dobara simple shabdon mein bolo."
    except Exception as e:
        return f"AI se connect nahi hua. Ollama chal raha hai? ({e})"

def respond(message, history):
    if not message.strip():
        return "", history
    reply = chat(message, history)
    history = history + [{"role": "user", "content": message}, {"role": "assistant", "content": reply}]
    return "", history

def quick_attach(files, history):
    """Chat se direct file daalo: PDF/DOCX/TXT -> books, image -> photos."""
    if not files: return history
    books, pics = [], 0
    for f in files:
        p = f if isinstance(f, str) else f.name
        ext = os.path.splitext(p)[1].lower()
        if ext in (".jpg", ".jpeg", ".png", ".webp", ".gif", ".bmp", ".heic"):
            shutil.copy(p, PHOTOS); pics += 1
        else:
            books.append(p)
    msg = []
    if pics: msg.append(f"{pics} photo My Photos mein save ki.")
    if books:
        s, _ = add_books(books); msg.append(s)
    return history + [{"role": "assistant", "content": " ".join(msg)}]

# ------------------------------------------------------------------ photos
def add_photos(files):
    for f in files or []:
        shutil.copy(f if isinstance(f, str) else f.name, PHOTOS)
    return photo_list(), f"{len(files or [])} photo save ho gayi."

def photo_list():
    return [os.path.join(PHOTOS, f) for f in sorted(os.listdir(PHOTOS), reverse=True)
            if f.lower().endswith((".jpg", ".jpeg", ".png", ".webp", ".gif", ".bmp"))]

# ------------------------------------------------------------------ settings
def installed_models():
    try:
        return [m.model for m in ollama.list().models]
    except Exception:
        return [CFG["model"]]

def save_settings(model, name, business, phone, gstin, address, autostart):
    CFG.update({"model": model, "bot_name": name or "Dost", "business": business, "phone": phone,
                "gstin": gstin, "address": address})
    save_cfg()
    startup = os.path.join(os.environ.get("APPDATA", ""), r"Microsoft\Windows\Start Menu\Programs\Startup", "PersonalAI.bat")
    try:
        if autostart:
            open(startup, "w").write(f'@echo off\ncd /d "{BASE}"\nstart "" /min cmd /c start.bat\n')
        elif os.path.exists(startup):
            os.remove(startup)
    except Exception:
        pass
    return "Settings save ho gayi."

def open_folder(which):
    p = {"Books": BOOKS, "Photos": PHOTOS, "Invoices": INVOICES, "Stories": STORIES}[which]
    try: os.startfile(p)
    except Exception: pass
    return f"Khola: {p}"

# ------------------------------------------------------------------ UI
GR6 = int(gr.__version__.split(".")[0]) >= 6
with gr.Blocks(title="Personal AI", **({} if GR6 else {"theme": gr.themes.Soft()})) as demo:
    gr.Markdown(f"## {CFG['bot_name']} - aapka offline Personal AI")
    with gr.Tab("Chat"):
        bot = gr.Chatbot(height=480, **({} if GR6 else {"type": "messages"}))
        with gr.Row():
            box = gr.Textbox(placeholder="Jaise: Downloads ki saari photo Pictures\\Shaadi mein daal do", scale=8, show_label=False)
            send = gr.Button("Bhejo", variant="primary", scale=1)
        with gr.Row():
            attach = gr.UploadButton("Book / Photo upload", file_count="multiple")
            undo = gr.Button("Last move Undo")
            clear = gr.Button("Naya chat")
        send.click(respond, [box, bot], [box, bot]); box.submit(respond, [box, bot], [box, bot])
        attach.upload(quick_attach, [attach, bot], bot)
        undo.click(lambda h: h + [{"role": "assistant", "content": undo_last()}], bot, bot)
        clear.click(lambda: [], None, bot)
        gr.Examples(["Desktop pe kya-kya hai?", "Downloads ki saari PDF Documents\\PDF folder mein move karo",
                     "Mere liye ek chhoti motivational story likho", "Kal subah 10 baje bank jaane ka reminder do",
                     "Meri books mein GST ke baare mein kya likha hai?"], box)
    with gr.Tab("Books"):
        bfiles = gr.File(label="PDF / Word / TXT books yahan daalo", file_count="multiple",
                         file_types=[".pdf", ".docx", ".txt"])
        badd = gr.Button("Upload & Padho", variant="primary")
        bstat = gr.Textbox(label="Status"); blist = gr.Textbox(label="Meri books", value=book_list(), lines=8)
        badd.click(add_books, bfiles, [bstat, blist])
    with gr.Tab("Photos"):
        pfiles = gr.File(label="Photos yahan daalo", file_count="multiple", file_types=["image"])
        padd = gr.Button("Upload", variant="primary"); pstat = gr.Markdown()
        gal = gr.Gallery(value=photo_list(), columns=5, height=420)
        padd.click(add_photos, pfiles, [gal, pstat])
    with gr.Tab("Invoice"):
        with gr.Row():
            icust = gr.Textbox(label="Customer naam"); igst = gr.Dropdown(["0", "5", "12", "18", "28"], value="18", label="GST %")
        iaddr = gr.Textbox(label="Customer address / GSTIN (optional)")
        iitems = gr.Textbox(label="Items (har line: naam, qty, rate)", lines=5, placeholder="AI Video Ad, 1, 4999\nReel editing, 4, 1500")
        ibtn = gr.Button("Invoice banao", variant="primary"); ifile = gr.File(label="Download"); istat = gr.Markdown()
        ibtn.click(invoice_from_form, [icust, iaddr, iitems, igst], [ifile, istat])
    with gr.Tab("Reminders"):
        with gr.Row():
            rtext = gr.Textbox(label="Kis baat ka", scale=3)
            rdate = gr.Textbox(label="Date (YYYY-MM-DD)", value=str(dt.date.today()))
            rtime = gr.Textbox(label="Time (HH:MM, 24 ghante)", value="10:00")
        radd = gr.Button("Reminder lagao", variant="primary"); rstat = gr.Markdown()
        rtab = gr.Dataframe(headers=["Kab", "Kya", "Status"], value=reminder_table(), interactive=False)
        rclr = gr.Button("Ho chuke reminders hatao")
        radd.click(add_reminder_form, [rtext, rdate, rtime], [rstat, rtab]); rclr.click(clear_done, None, rtab)
        gr.Markdown("Reminder tabhi bajega jab ye app chalu ho. Settings mein 'Windows ke saath start' on kar do.")
    with gr.Tab("Settings"):
        smodel = gr.Dropdown(installed_models(), value=CFG["model"], label="AI model")
        sname = gr.Textbox(label="Bot ka naam", value=CFG["bot_name"])
        sbiz = gr.Textbox(label="Business naam (invoice ke liye)", value=CFG.get("business", ""))
        sph = gr.Textbox(label="Phone", value=CFG.get("phone", "")); sgst = gr.Textbox(label="GSTIN", value=CFG.get("gstin", ""))
        sadd = gr.Textbox(label="Address", value=CFG.get("address", ""))
        sauto = gr.Checkbox(label="Windows ke saath apne aap start ho", value=os.path.exists(os.path.join(
            os.environ.get("APPDATA", ""), r"Microsoft\Windows\Start Menu\Programs\Startup", "PersonalAI.bat")))
        ssave = gr.Button("Save", variant="primary"); sstat = gr.Markdown()
        ssave.click(save_settings, [smodel, sname, sbiz, sph, sgst, sadd, sauto], sstat)
        with gr.Row():
            for w in ("Books", "Photos", "Invoices", "Stories"):
                gr.Button(f"{w} folder kholo").click(lambda w=w: open_folder(w), None, sstat)

if __name__ == "__main__":
    threading.Thread(target=reminder_loop, daemon=True).start()
    demo.launch(server_name="127.0.0.1", inbrowser=True, allowed_paths=[DATA],
                **({"theme": gr.themes.Soft()} if GR6 else {}))
