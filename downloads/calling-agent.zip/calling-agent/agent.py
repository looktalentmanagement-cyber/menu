"""
AK Media AI Calling Agent (Windows + Android phone)
- Phone Link (Bluetooth) carries call audio to the laptop
- ADB over USB dials / answers / hangs up
- Gemini Live API listens and talks in real time
- Every call is recorded (stereo WAV: left = client, right = agent) + transcript + summary

Usage:
  python agent.py outbound      # calls everyone in leads.csv one by one
  python agent.py inbound       # waits for incoming calls and answers them
  python agent.py devices       # lists audio devices
"""
import asyncio, csv, datetime as dt, os, queue, subprocess, sys, time, wave
import numpy as np
import sounddevice as sd
from scipy.signal import resample_poly
from google import genai
from google.genai import types

# ---------------- SETTINGS ----------------
API_KEY      = os.environ.get("GEMINI_API_KEY", "PASTE_YOUR_KEY_HERE")
LIVE_MODEL   = "gemini-3.8-live"          # Gemini Live voice model
TEXT_MODEL   = "gemini-flash-latest"      # for call summary
VOICE        = "Sulafat"                  # female: Sulafat (warm), Aoede, Leda, Kore, Despina
IN_DEVICE    = "CABLE Output"             # phone audio comes in here (VB-Cable)
OUT_DEVICE   = "Hi-Fi Cable Input"        # agent voice goes out here (Hi-Fi Cable)
DEV_RATE     = 48000                      # Windows device rate
MAX_CALL_SEC = 300                        # hard limit per call
GAP_BETWEEN_CALLS = 20                    # seconds
ADB          = "adb"                      # or full path to platform-tools\adb.exe
# ------------------------------------------

BASE = os.path.dirname(os.path.abspath(__file__))
REC_DIR = os.path.join(BASE, "recordings"); os.makedirs(REC_DIR, exist_ok=True)
SCRIPT = open(os.path.join(BASE, "script.txt"), encoding="utf-8").read()
KB = os.path.join(BASE, "knowledge.txt")
if os.path.exists(KB):
    SCRIPT += "\n\nTUMHARI COMPANY KI POORI JAANKARI (rates, plans, FAQ). Sirf isi se rate batao:\n" + open(KB, encoding="utf-8").read()
client = genai.Client(api_key=API_KEY)

def adb(*args):
    return subprocess.run([ADB, *args], capture_output=True, text=True).stdout

def call_state():
    """0 = idle, 1 = ringing, 2 = in call / dialing"""
    out = adb("shell", "dumpsys", "telephony.registry")
    for line in out.splitlines():
        line = line.strip()
        if line.startswith("mCallState="):
            try: return int(line.split("=")[1])
            except: pass
    return 0

def dial(number):   adb("shell", "am", "start", "-a", "android.intent.action.CALL", "-d", f"tel:{number}")
def answer():       adb("shell", "input", "keyevent", "79")   # HEADSETHOOK answers on most phones
def hang_up():      adb("shell", "input", "keyevent", "6")    # ENDCALL

def find_device(name, kind):
    for i, d in enumerate(sd.query_devices()):
        if name.lower() in d["name"].lower() and d[f"max_{kind}_channels"] > 0:
            return i
    raise SystemExit(f"Audio device '{name}' not found. Run: python agent.py devices")

END_CALL_TOOL = {"function_declarations": [{
    "name": "end_call",
    "description": "Call khatam karo jab baat poori ho jaye ya client mana kare.",
}]}

async def run_call(name, phone):
    stamp = dt.datetime.now().strftime("%Y%m%d_%H%M%S")
    base = os.path.join(REC_DIR, f"{stamp}_{phone.replace('+','')}")
    wav = wave.open(base + ".wav", "wb"); wav.setnchannels(2); wav.setsampwidth(2); wav.setframerate(16000)
    transcript = []
    mic_q: "queue.Queue[bytes]" = queue.Queue()
    play_buf = bytearray()          # agent audio at 48k, int16
    done = asyncio.Event()

    def callback(indata, outdata, frames, t, status):
        client_48 = indata[:, 0].copy()
        need = frames * 2
        chunk = bytes(play_buf[:need]); del play_buf[:need]
        agent_48 = np.frombuffer(chunk.ljust(need, b"\0"), dtype=np.int16)
        outdata[:, 0] = agent_48
        c16 = resample_poly(client_48, 1, 3).astype(np.int16)
        a16 = resample_poly(agent_48, 1, 3).astype(np.int16)
        mic_q.put(c16.tobytes())
        wav.writeframes(np.column_stack([c16, a16]).astype(np.int16).tobytes())

    config = {
        "response_modalities": ["AUDIO"],
        "system_instruction": SCRIPT + f"\n\nClient ka naam (agar pata ho): {name}",
        "speech_config": {"voice_config": {"prebuilt_voice_config": {"voice_name": VOICE}}},
        "input_audio_transcription": {},
        "output_audio_transcription": {},
        "tools": [END_CALL_TOOL, {"google_search": {}}],
    }
    stream = sd.Stream(device=(find_device(IN_DEVICE, "input"), find_device(OUT_DEVICE, "output")),
                       samplerate=DEV_RATE, channels=1, dtype="int16", blocksize=960, callback=callback)
    start = time.time()
    async with client.aio.live.connect(model=LIVE_MODEL, config=config) as session:
        async def sender():
            while not done.is_set():
                try: data = mic_q.get_nowait()
                except queue.Empty: await asyncio.sleep(0.01); continue
                await session.send_realtime_input(audio=types.Blob(data=data, mime_type="audio/pcm;rate=16000"))
        async def receiver():
            while not done.is_set():
                async for r in session.receive():
                    if r.data:
                        a24 = np.frombuffer(r.data, dtype=np.int16)
                        play_buf.extend(resample_poly(a24, 2, 1).astype(np.int16).tobytes())
                    sc = r.server_content
                    if sc:
                        if sc.input_transcription and sc.input_transcription.text:
                            transcript.append(("Client", sc.input_transcription.text))
                        if sc.output_transcription and sc.output_transcription.text:
                            transcript.append(("Agent", sc.output_transcription.text))
                        if sc.interrupted: play_buf.clear()   # client interrupted, stop talking
                    if r.tool_call:
                        for fc in r.tool_call.function_calls:
                            if fc.name == "end_call":
                                await session.send_tool_response(function_responses=[
                                    types.FunctionResponse(id=fc.id, name=fc.name, response={"ok": True})])
                                await asyncio.sleep(3)   # let goodbye finish
                                done.set()
        async def watchdog():
            await asyncio.sleep(4)
            while not done.is_set():
                if call_state() == 0 or time.time() - start > MAX_CALL_SEC:
                    done.set()
                await asyncio.sleep(1)
        with stream:
            tasks = [asyncio.create_task(x()) for x in (sender, receiver, watchdog)]
            await done.wait()
            for t in tasks: t.cancel()
    hang_up(); wav.close()
    secs = int(time.time() - start)

    # merge transcript pieces and save
    lines, last = [], None
    for who, txt in transcript:
        if who == last: lines[-1] += txt
        else: lines.append(f"{who}: {txt}"); last = who
    text = "\n".join(lines)
    open(base + ".txt", "w", encoding="utf-8").write(text)

    summary = ""
    if text.strip():
        try:
            summary = client.models.generate_content(model=TEXT_MODEL, contents=
                "Is sales call ka 1 line summary do aur result likho: INTERESTED / CALL BACK / NOT INTERESTED / NO ANSWER. "
                "Client ka mood aur demo time (agar fix hua) bhi likho.\n\n" + text).text.strip().replace("\n", " ")
        except Exception as e:
            summary = f"summary error: {e}"
    else:
        summary = "NO ANSWER / no speech"
    new = not os.path.exists(os.path.join(BASE, "results.csv"))
    with open(os.path.join(BASE, "results.csv"), "a", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        if new: w.writerow(["time", "name", "phone", "seconds", "recording", "summary"])
        w.writerow([stamp, name, phone, secs, os.path.basename(base) + ".wav", summary])
    print(f"  done in {secs}s -> {summary}")

async def outbound():
    rows = list(csv.DictReader(open(os.path.join(BASE, "leads.csv"), encoding="utf-8")))
    for row in rows:
        print(f"Calling {row['name']} {row['phone']} ...")
        dial(row["phone"])
        for _ in range(20):               # wait for the call to start
            if call_state() == 2: break
            await asyncio.sleep(0.5)
        await run_call(row["name"], row["phone"])
        await asyncio.sleep(GAP_BETWEEN_CALLS)

async def inbound():
    print("Waiting for incoming calls... (Ctrl+C to stop)")
    while True:
        if call_state() == 1:
            print("Incoming call, answering")
            answer(); await asyncio.sleep(1.5)
            await run_call("Incoming", "incoming")
        await asyncio.sleep(1)

if __name__ == "__main__":
    mode = sys.argv[1] if len(sys.argv) > 1 else "outbound"
    if mode == "devices": print(sd.query_devices())
    elif mode == "inbound": asyncio.run(inbound())
    else: asyncio.run(outbound())
